

def search(sequence, target):
    #loop, through the list
    for i in range(len(sequence)):
        #if current element is the target --> return index
        if sequence[i] == target:
            return i
    
    #target was not found
    return -1

#test cases

grades = [74, 99, 17, 49, 15, 68, 82, 11, 27, 18, 89, 93, 76]

print(search(grades, 75)) # -1
print(search(grades, 15)) # 4
print(search(grades, 74)) # 0
print(search(grades, 76)) # 12