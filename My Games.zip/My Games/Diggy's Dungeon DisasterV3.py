##################
###PREGAME CODE###
##################


###IMPORTS AND INITIALIZATIONS

import pygame
pygame.init() 
import math
#Is used to help locate and load files/assets
import os
from os import listdir
from os.path import isfile, join


###WINDOW DISPLAY SETUP
 
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 700
WINDOW = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Diggy's Dungeon Disaster")
#Helps to max out how many times the screen can reload per second so that different computers can run at similar speeds
FPS = 60


##ASSETS
BACKGROUND = pygame.image.load(join("assets", "Background", "Cave Dungeon.png"))
VELOCITY = 5

###COLOUR CONSTANTS

BLACK = (0,0,0)
GOLD = (255,215,0)


###SPRITE FUNCTIONS



###CLASSES

#The pygame.sprite.Sprite module gives us a method that will help with object collision
class Player(pygame.sprite.Sprite):
    GRAVITY = 1
    ANIMATION_DELAY = 5

    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
        self.x_vel = 0
        self.y_vel = 0
        self.mask = None
        self.direction = "left"
        self.animation_count = 0
        self.fall_count = 0
    
    def move(self, dx, dy):
        self.rect.x += dx
        self.rect.y += dy
    
    def move_left(self, vel):
        self.x_vel = - vel
        if self.direction != "left":
            self.direction = "left"
            self.animation_count = 0

    def move_right(self, vel):
        self.x_vel = vel
        if self.direction != "right":
            self.direction = "right"
            self.animation_count = 0
    
    def loop(self, fps):
        if 0 < self.y_vel > WINDOW_HEIGHT - 5 and 0 < self.x_vel > WINDOW_WIDTH:
            self.y_vel += min(1, (self.fall_count / fps) * self.GRAVITY) 
            self.move(self.x_vel, self.y_vel)
            self.fall_count += 1
    

    
    def draw(self, screen):
        pygame.draw.rect(screen, GOLD, self.rect)


###GAME FUNCTIONS

#An organizational function that will draw and update what displays on the window
def draw(screen, background, player):
    screen.blit(background,(0,0))
    player.draw(screen)

    pygame.display.update()


def handle_move(player):
    #Allows the user to move and give input
    keys = pygame.key.get_pressed()
    player.x_vel = 0
    if keys[pygame.K_a]:
        player.move_left(VELOCITY)
    if keys[pygame.K_d]:
        player.move_right(VELOCITY)         








###############
###GAME CODE###
###############

def main():
    CLOCK = pygame.time.Clock()
    player = Player(350, 350, 50, 50)

    #run until user closes the display window 
    closed = False 
    while not closed:
        #Helps to max out how many times the screen can reload per second so that different computers can run at similar speeds
        CLOCK.tick(FPS)

    
        #loop through possible keyboard and mouse events 
        for event in pygame.event.get():


            #if user clicks on close button (X) in top R corner -> close window 
            if event.type == pygame.QUIT: 
                closed = True 
                break
        
        player.loop(FPS)
        handle_move(player)
        draw(WINDOW,BACKGROUND, player)

    #user is done -> terminate program 
    pygame.quit() 
 
#call main method 
if __name__ == "__main__": 
    main()